// Alunos: Ana Beatriz da Conceição, Karin Araldi, Kauan Borges Kuball
// Aviso: É necessario alterar na parte que abre o csv o endereço do csv

#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstdlib>
#include <ctime>
#include <limits>
#include <locale.h>

using namespace std;

// Definição da estrutura de filme
struct Filme {
    string titulo;
    string genero;
    string elenco;
};

// Definição da estrutura de usuário
struct Usuario {
    string nome;
    int idade;
    string generosFavoritos[3];
    Filme assistidos[50];
    Filme assistirDepois[50];       // Lista de filmes para assistir depois
    Filme recomendados[10];
};

// TAD de Lista Estática Genérica
template <typename T, int MAX_SIZE>
struct ListaEstatica {
    T elementos[MAX_SIZE];
    int tamanho;

    ListaEstatica() {
        tamanho = 0;
    }

    void inserir(const T& item, int posicao) {
        if (tamanho >= MAX_SIZE) {
            cout << "Lista cheia, impossivel inserir." << endl;
            return;
        }
        if (posicao < 0 || posicao > tamanho) {
            cout << "Posição invalida." << endl;
            return;
        }
        elementos[tamanho] = item;    // Adiciona na última posição livre
        ++tamanho;
    }

    void remover(int posicao) {
        if (tamanho <= 0 || posicao < 0 || posicao >= tamanho) {
            cout << "Lista vazia ou posicao invalida." << endl;
            return;
        }
        for (int i = posicao; i < tamanho - 1; ++i) {
            elementos[i] = elementos[i + 1];
        }
        --tamanho;
    }

    T obter(int posicao) {
        if (posicao < 0 || posicao >= tamanho) {
            cout << "Posicao invalida." << endl;
            return T();
        }
        return elementos[posicao];
    }

    bool contem(const T& item) {
        for (int i = 0; i < tamanho; ++i) {
            if (elementos[i] == item) {
                return true;
            }
        }
        return false;
    }

    int descobrirIndice(const T& item) {
        for (int i = 0; i < tamanho; ++i) {
            if (elementos[i] == item) {
                return i;
            }
        }
        return -1;
    }

    void imprimir() {
        for (int i = 0; i < tamanho; ++i) {
            cout << elementos[i] << " ";
        }
        cout << endl;
    }
};

// Função para inicializar o catálogo de filmes a partir de um arquivo CSV
void inicializarCatalogo(Filme catalogo[], int tamanho, const string& arquivoCSV) {
    ifstream arquivo(arquivoCSV);
    if (!arquivo.is_open()) {
        cerr << "Erro ao abrir o arquivo " << arquivoCSV << endl;
        return;
    }

    string linha;
    getline(arquivo, linha);    // Ignora o cabeçalho

    for (int i = 0; i < tamanho; ++i) {
        if (!getline(arquivo, linha)) {
            cerr << "Erro: numero insuficiente de linhas no arquivo." << endl;
            break;
        }
        stringstream ss(linha);
        getline(ss, catalogo[i].titulo, ',');
        getline(ss, catalogo[i].genero, ',');
        getline(ss, catalogo[i].elenco, ',');
    }

    arquivo.close();
}

// Função para adicionar filmes manualmente à lista de filmes assistidos
void adicionarFilmesManualmente(Usuario& usuario, ListaEstatica<Filme, 50>& lista, Filme catalogo[], int tamanhoCatalogo, int quantidade) {
    cout << "Adicione os filmes manualmente:" << endl;
    for (int i = 0; i < quantidade; ++i) {
        if (lista.tamanho < 50) {
            Filme filme;
            cout << "Filme " << i + 1 << ": " << endl;
            cout << "Titulo: ";
            cin.ignore(numeric_limits<streamsize>::max(), '\n');   // Limpar o buffer do teclado
            getline(cin, filme.titulo);
            cout << "Genero: ";
            getline(cin, filme.genero);
            cout << "Elenco: ";
            getline(cin, filme.elenco);
            lista.inserir(filme, lista.tamanho);    // Adiciona na última posição livre
        }
        else {
            cout << "A lista de filmes esta cheia." << endl;
            break;
        }
    }
    cout << "Filmes adicionados com sucesso." << endl;
}

// Função para adicionar filmes aleatoriamente à lista de filmes assistidos
void adicionarFilmesAleatorios(Usuario& usuario, ListaEstatica<Filme, 50>& lista, Filme catalogo[], int tamanhoCatalogo, int quantidade) {
    cout << "Adicionando filmes aleatorios:" << endl;
    srand(time(nullptr));

    while (lista.tamanho < 50 && quantidade > 0) {
        int indice = rand() % tamanhoCatalogo;
        bool jaAssistido = false;

        // Verifica se o filme já está na lista de assistidos
        for (int i = 0; i < lista.tamanho; ++i) {
            if (lista.elementos[i].titulo == catalogo[indice].titulo) {
                jaAssistido = true;
                break;
            }
        }

        if (!jaAssistido) {
            lista.inserir(catalogo[indice], lista.tamanho);    // Adiciona na última posição livre
            quantidade--;
        }
    }

    cout << "Filmes aleatorios adicionados com sucesso." << endl;
}

// Função para adicionar filmes manualmente à lista de filmes para assistir depois
void adicionarFilmesParaAssistirDepoisManualmente(Usuario& usuario, ListaEstatica<Filme, 50>& lista, Filme catalogo[], int tamanhoCatalogo, int quantidade) {
    cout << "Adicione os filmes para assistir depois manualmente:" << endl;
    for (int i = 0; i < quantidade; ++i) {
        if (lista.tamanho < 50) {
            Filme filme;
            cout << "Filme " << i + 1 << ": " << endl;
            cout << "Titulo: ";
            cin.ignore(numeric_limits<streamsize>::max(), '\n');   // Limpar o buffer do teclado
            getline(cin, filme.titulo);
            cout << "Genero: ";
            getline(cin, filme.genero);
            cout << "Elenco: ";
            getline(cin, filme.elenco);
            lista.inserir(filme, lista.tamanho);    // Adiciona na última posição livre
        }
        else {
            cout << "A lista de filmes para assistir depois está cheia." << endl;
            break;
        }
    }
    cout << "Filmes adicionados para assistir depois com sucesso." << endl;
}

// Função para adicionar filmes aleatoriamente à lista de filmes para assistir depois
void adicionarFilmesParaAssistirDepoisAleatoriamente(Usuario& usuario, ListaEstatica<Filme, 50>& lista, Filme catalogo[], int tamanhoCatalogo, int quantidade) {
    cout << "Adicionando filmes para assistir depois aleatoriamente:" << endl;
    srand(time(nullptr));

    while (lista.tamanho < 50 && quantidade > 0) {
        int indice = rand() % tamanhoCatalogo;
        bool jaAssistido = false;

        // Verifica se o filme já está na lista de assistidos ou na lista de assistir depois
        for (int i = 0; i < lista.tamanho; ++i) {
            if (lista.elementos[i].titulo == catalogo[indice].titulo) {
                jaAssistido = true;
                break;
            }
        }

        if (!jaAssistido) {
            lista.inserir(catalogo[indice], lista.tamanho);    // Adiciona na última posição livre
            quantidade--;
        }
    }

    cout << "Filmes aleatorios adicionados para assistir depois com sucesso." << endl;
}

// Função para remover filmes da lista para assistir depois
void removerFilmeDaListaParaAssistirDepois(Usuario& usuario, ListaEstatica<Filme, 50>& lista, int indice) {
    if (indice < 0 || indice >= lista.tamanho || lista.elementos[indice].titulo.empty()) {
        cout << "Indice invalido ou filme não encontrado na lista para assistir depois." << endl;
        return;
    }

    lista.elementos[indice].titulo.clear();
    lista.elementos[indice].genero.clear();
    lista.elementos[indice].elenco.clear();

    // Realoca os filmes na lista após a remoção
    for (int i = indice; i < lista.tamanho - 1; ++i) {
        lista.elementos[i] = lista.elementos[i + 1];
    }
    lista.elementos[lista.tamanho - 1].titulo.clear();
    lista.elementos[lista.tamanho - 1].genero.clear();
    lista.elementos[lista.tamanho - 1].elenco.clear();

    lista.tamanho--;

    cout << "Filme removido da lista para assistir depois com sucesso." << endl;
}

// Função para gerar recomendações para o usuário com base em seus gêneros favoritos
void gerarRecomendacoesPorGenero(Usuario& usuario, Filme catalogo[], int tamanhoCatalogo) {
    for (int i = 0; i < 10; ++i) {
        usuario.recomendados[i].titulo.clear();
        usuario.recomendados[i].genero.clear();
        usuario.recomendados[i].elenco.clear();
    }

    int count = 0;
    for (int i = 0; i < tamanhoCatalogo && count < 10; ++i) {
        bool generoFavorito = false;
        for (int j = 0; j < 3; ++j) {
            if (usuario.generosFavoritos[j] == catalogo[i].genero) {
                generoFavorito = true;
                break;
            }
        }
        if (generoFavorito) {
            usuario.recomendados[count++] = catalogo[i];
        }
    }
}

// Função para imprimir todos os filmes assistidos
void imprimirFilmesAssistidos(Usuario& usuario, ListaEstatica<Filme, 50>& lista) {
    cout << "Filmes assistidos por " << usuario.nome << ":" << endl;
    for (int i = 0; i < lista.tamanho; ++i) {
        cout << "Titulo: " << lista.elementos[i].titulo << ", Genero: " << lista.elementos[i].genero << ", Elenco: " << lista.elementos[i].elenco << endl;
    }
    if (lista.tamanho == 0) {
        cout << "Nenhum filme assistido encontrado." << endl;
    }
}

int main() {
    setlocale(LC_ALL, "Portuguese");

    string arquivoCSV = "C:\\Users\\karin_9avue23\\Downloads\\Trabalho Estrutura de Dados\\Movies.csv";
    const int tamanhoCatalogo = 500;
    Filme catalogo[tamanhoCatalogo];
    inicializarCatalogo(catalogo, tamanhoCatalogo, arquivoCSV);

    Usuario usuario;
    ListaEstatica<Filme, 50> listaAssistidos;
    ListaEstatica<Filme, 50> listaParaAssistirDepois;

    cout << "Informe o nome do usuario: ";
    cin >> usuario.nome;
    cout << "Informe a idade do usuario: ";
    cin >> usuario.idade;

    cout << "Informe seus 3 generos de filmes favoritos:" << endl;
    for (int i = 0; i < 3; ++i) {
        cout << "Genero " << i + 1 << ": ";
        cin >> usuario.generosFavoritos[i];
    }

    int escolha;
    do {
        cout << "\nEscolha uma acao para o usuario:" << endl;
        cout << "1. Adicionar filmes assistidos manualmente" << endl;
        cout << "2. Adicionar filmes assistidos aleatoriamente" << endl;
        cout << "3. Adicionar filmes para assistir depois manualmente" << endl;
        cout << "4. Adicionar filmes para assistir depois aleatoriamente" << endl;
        cout << "5. Remover filme da lista para assistir depois" << endl;
        cout << "6. Ver filmes assistidos" << endl;
        cout << "7. Ver filmes para assistir depois" << endl;
        cout << "8. Ver filmes recomendados" << endl;
        cout << "9. Gerar recomendacoes por genero" << endl;
        cout << "10. Sair" << endl;
        cin >> escolha;

        switch (escolha) {
        case 1: {
            int quantidade;
            cout << "Quantidade de filmes a serem adicionados manualmente: ";
            cin >> quantidade;
            adicionarFilmesManualmente(usuario, listaAssistidos, catalogo, tamanhoCatalogo, quantidade);
            break;
        }
        case 2: {
            int quantidade;
            cout << "Quantidade de filmes a serem adicionados aleatoriamente: ";
            cin >> quantidade;
            adicionarFilmesAleatorios(usuario, listaAssistidos, catalogo, tamanhoCatalogo, quantidade);
            break;
        }
        case 3: {
            int quantidade;
            cout << "Quantidade de filmes a serem adicionados manualmente para assistir depois: ";
            cin >> quantidade;
            adicionarFilmesParaAssistirDepoisManualmente(usuario, listaParaAssistirDepois, catalogo, tamanhoCatalogo, quantidade);
            break;
        }
        case 4: {
            int quantidade;
            cout << "Quantidade de filmes a serem adicionados aleatoriamente para assistir depois: ";
            cin >> quantidade;
            adicionarFilmesParaAssistirDepoisAleatoriamente(usuario, listaParaAssistirDepois, catalogo, tamanhoCatalogo, quantidade);
            break;
        }
        case 5: {
            int indice;
            cout << "Índice do filme a ser removido da lista para assistir depois: ";
            cin >> indice;
            removerFilmeDaListaParaAssistirDepois(usuario, listaParaAssistirDepois, indice);
            break;
        }
        case 6: {
            imprimirFilmesAssistidos(usuario, listaAssistidos);
            break;
        }
        case 7: {
            cout << "Filmes para assistir depois adicionados por " << usuario.nome << ":" << endl;
            for (int i = 0; i < listaParaAssistirDepois.tamanho; ++i) {
                cout << "Titulo: " << listaParaAssistirDepois.elementos[i].titulo << ", Genero: " << listaParaAssistirDepois.elementos[i].genero << ", Elenco: " << listaParaAssistirDepois.elementos[i].elenco << endl;
            }
            if (listaParaAssistirDepois.tamanho == 0) {
                cout << "Nenhum filme para assistir depois encontrado." << endl;
            }
            break;
        }
        case 8: {
            gerarRecomendacoesPorGenero(usuario, catalogo, tamanhoCatalogo);
            cout << "Filmes recomendados para " << usuario.nome << ":" << endl;
            for (int i = 0; i < 10; ++i) {
                cout << "Titulo: " << usuario.recomendados[i].titulo << ", Genero: " << usuario.recomendados[i].genero << ", Elenco: " << usuario.recomendados[i].elenco << endl;
            }
            break;
        }
        case 9: {
            gerarRecomendacoesPorGenero(usuario, catalogo, tamanhoCatalogo);
            cout << "Recomendacoes para " << usuario.nome << " com base nos generos favoritos:" << endl;
            for (int i = 0; i < 10; ++i) {
                cout << "Titulo: " << usuario.recomendados[i].titulo << ", Genero: " << usuario.recomendados[i].genero << ", Elenco: " << usuario.recomendados[i].elenco << endl;
            }
            break;
        }
        case 10: {
            cout << "Saindo do programa." << endl;
            break;
        }
        default: {
            cout << "Opção invalida. Por favor, tente novamente." << endl;
            break;
        }
        }
    } while (escolha != 10);
    
    return 0;
}